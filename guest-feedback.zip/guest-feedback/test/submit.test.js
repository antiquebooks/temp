"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const crypto = require("node:crypto");

const config = require("../public/config.json");
const { validate } = require("../netlify/lib/validate");
const { signJwt } = require("../netlify/lib/sheets");
const { buildAlert } = require("../netlify/lib/alert");
const { handler } = require("../netlify/functions/submit");

// ---- environment + fetch mock ------------------------------------------------
const { privateKey, publicKey } = crypto.generateKeyPairSync("rsa", { modulusLength: 2048 });
process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL = "svc@example.iam.gserviceaccount.com";
process.env.GOOGLE_PRIVATE_KEY = privateKey.export({ type: "pkcs8", format: "pem" }).replace(/\n/g, "\\n");
process.env.GOOGLE_SHEET_ID = "sheet123";
process.env.RESEND_API_KEY = "re_test";
process.env.ALERT_TO_EMAIL = "host@example.com";
process.env.GOOGLE_TRANSLATE_API_KEY = "tr_test";
delete process.env.DRY_RUN;

let calls;
let failSheet = false;
function installFetch() {
  calls = [];
  globalThis.fetch = async (url, opts = {}) => {
    const u = String(url);
    calls.push({ url: u, body: opts.body });
    const json = (data, status = 200) => ({ ok: status < 400, status, json: async () => data, text: async () => JSON.stringify(data) });
    if (u.includes("oauth2.googleapis.com")) return json({ access_token: "tok", expires_in: 3600 });
    if (u.includes("sheets.googleapis.com")) return failSheet ? json({ error: "nope" }, 500) : json({ updates: {} });
    if (u.includes("api.resend.com")) return json({ id: "mail1" });
    if (u.includes("translation.googleapis.com")) {
      const q = JSON.parse(opts.body).q;
      return json({ data: { translations: q.map((t) => ({ translatedText: `EN:${t}`, detectedSourceLanguage: t.startsWith("english") ? "en" : "sk" })) } });
    }
    throw new Error("unexpected fetch " + u);
  };
}

let ipCounter = 0;
const send = (payload, extra = {}) =>
  handler({
    httpMethod: "POST",
    headers: { "x-nf-client-connection-ip": `10.0.0.${++ipCounter}` },
    body: JSON.stringify({ t: 8000, website: "", lang: "en", tags: [], comments: {}, ...payload }),
    ...extra
  });
const sheetCall = () => calls.find((c) => c.url.includes("sheets.googleapis.com"));
const emailCall = () => calls.find((c) => c.url.includes("api.resend.com"));

test.beforeEach(() => { installFetch(); failSheet = false; delete process.env.GOOGLE_REVIEW_URL_HOUSE; });

// ---- validation ----------------------------------------------------------------
test("validate: rejects unknown property and bad rating", () => {
  assert.equal(validate({ p: "villa", rating: 5 }, config).error, "unknown_property");
  assert.equal(validate({ p: "flat1", rating: 6 }, config).error, "bad_rating");
  assert.equal(validate({ p: "flat1", rating: "5" }, config).error, "bad_rating");
  assert.equal(validate({ p: "__proto__", rating: 5 }, config).error, "unknown_property");
});

test("validate: keeps only tags allowed for that property and trims comments", () => {
  const r = validate({
    p: "flat3", rating: 2, lang: "xx",
    tags: ["equipment:workspace", "equipment:bbq", "location:garden", "bogus", "equipment:workspace"],
    comments: { general: "  hello  ", cleanliness: "", evil: "x" }
  }, config).value;
  assert.deepEqual(r.tags, ["equipment:workspace"]);   // bbq/garden belong to the house only
  assert.equal(r.lang, "en");
  assert.deepEqual(r.comments, { general: "hello" });
});

// ---- spam protection -----------------------------------------------------------
test("honeypot and too-fast submissions are ignored but look successful", async () => {
  let res = await send({ p: "flat1", rating: 1, website: "http://spam" });
  assert.equal(res.statusCode, 200);
  res = await send({ p: "flat1", rating: 1, t: 500 });
  assert.equal(res.statusCode, 200);
  assert.equal(calls.length, 0);
});

test("rate limit returns 429 after too many submissions from one IP", async () => {
  const headers = { "x-nf-client-connection-ip": "203.0.113.9" };
  let last;
  for (let i = 0; i < 9; i++) {
    last = await handler({ httpMethod: "POST", headers, body: JSON.stringify({ t: 9000, p: "flat1", rating: 5 }) });
  }
  assert.equal(last.statusCode, 429);
});

// ---- Google review gating ------------------------------------------------------
test("google link: only house + 5 stars (+ URL configured)", async () => {
  const url = "https://g.page/r/example/review";
  process.env.GOOGLE_REVIEW_URL_HOUSE = url;
  assert.equal(JSON.parse((await send({ p: "house", rating: 5 })).body).google, url);
  assert.equal(JSON.parse((await send({ p: "house", rating: 4 })).body).google, null);
  assert.equal(JSON.parse((await send({ p: "flat1", rating: 5 })).body).google, null);
  delete process.env.GOOGLE_REVIEW_URL_HOUSE;
  assert.equal(JSON.parse((await send({ p: "house", rating: 5 })).body).google, null);
});

// ---- storage + alerts ----------------------------------------------------------
test("5-star response: stored in sheet, no email, no translation call", async () => {
  const res = await send({ p: "flat2", rating: 5, comments: { general: "Super" } });
  assert.equal(res.statusCode, 200);
  assert.ok(sheetCall());
  assert.equal(emailCall(), undefined);
  assert.equal(calls.some((c) => c.url.includes("translation")), false);
  const row = JSON.parse(sheetCall().body).values[0];
  assert.equal(row[1], "Flat 2");
  assert.equal(row[3], 5);
  assert.equal(row[5], "Super");
  assert.equal(row.length, 14);
  assert.match(sheetCall().url, /valueInputOption=RAW/);
});

test("rating 3 or below: translates, emails the host in English, logs alert status", async () => {
  const res = await send({
    p: "flat1", rating: 2, lang: "sk",
    tags: ["condition:hotWater", "comfort:noise"],
    comments: { general: "Nefungovala teplá voda", condition: "english text already" }
  });
  assert.equal(res.statusCode, 200);

  const mail = JSON.parse(emailCall().body);
  assert.deepEqual(mail.to, ["host@example.com"]);
  assert.match(mail.subject, /Low rating 2\/5 - Flat 1/);
  assert.match(mail.text, /Hot water/);
  assert.match(mail.text, /EN:Nefungovala teplá voda/);
  assert.doesNotMatch(mail.text, /EN:english text already/);   // already English: no translation shown

  const row = JSON.parse(sheetCall().body).values[0];
  assert.equal(row[4], "condition:hotWater, comfort:noise");
  assert.match(row[12], /EN:Nefungovala/);
  assert.equal(row[13], "sent");
});

test("alert still works without a translate key", async () => {
  delete process.env.GOOGLE_TRANSLATE_API_KEY;
  const res = await send({ p: "flat3", rating: 1, comments: { general: "Hluk" } });
  process.env.GOOGLE_TRANSLATE_API_KEY = "tr_test";
  assert.equal(res.statusCode, 200);
  assert.ok(emailCall());
});

test("sheet failure for a high rating returns 500 so the guest can retry", async () => {
  failSheet = true;
  const res = await send({ p: "flat1", rating: 5 });
  assert.equal(res.statusCode, 500);
});

test("sheet failure for a low rating still succeeds if the alert email went out", async () => {
  failSheet = true;
  const res = await send({ p: "flat1", rating: 1, comments: { general: "broken" } });
  assert.equal(res.statusCode, 200);
});

test("HTML in comments is escaped in the alert email", () => {
  const { html } = buildAlert({
    submission: { property: config.properties.flat1, rating: 1, lang: "en", tags: [], comments: { general: "<script>alert(1)</script>" } },
    when: "now", translations: {}
  });
  assert.doesNotMatch(html, /<script>/);
  assert.match(html, /&lt;script&gt;/);
});

// ---- Google service account JWT -------------------------------------------------
test("signJwt produces a verifiable RS256 token", () => {
  const pem = privateKey.export({ type: "pkcs8", format: "pem" });
  const jwt = signJwt("svc@example.com", pem, 1000);
  const [h, c, s] = jwt.split(".");
  assert.deepEqual(JSON.parse(Buffer.from(h, "base64url")), { alg: "RS256", typ: "JWT" });
  assert.equal(JSON.parse(Buffer.from(c, "base64url")).iss, "svc@example.com");
  const ok = crypto.createVerify("RSA-SHA256").update(`${h}.${c}`).verify(publicKey, s, "base64url");
  assert.equal(ok, true);
});

// ---- config sanity ----------------------------------------------------------------
test("every configured tag has a label in all five languages", () => {
  const I18N = require("../public/i18n.js");
  for (const lang of I18N.languages) {
    for (const cat of config.categories) {
      assert.ok(I18N[lang].cat[cat], `${lang} cat ${cat}`);
      assert.ok(I18N[lang].cathint[cat], `${lang} cathint ${cat}`);
    }
    for (const [pid, prop] of Object.entries(config.properties)) {
      for (const [cat, tags] of Object.entries(prop.tags)) {
        assert.ok(config.categories.includes(cat), `${pid}: unknown category ${cat}`);
        for (const tag of tags) assert.ok(I18N[lang].tag[tag], `${lang} tag ${tag} (${pid})`);
      }
    }
    const enKeys = Object.keys(I18N.en.ui).sort().join();
    assert.equal(Object.keys(I18N[lang].ui).sort().join(), enKeys, `${lang} ui keys match English`);
  }
});
