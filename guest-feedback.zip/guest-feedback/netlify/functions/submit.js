"use strict";

const config = require("../../public/config.json");
const { validate } = require("../lib/validate");
const { appendRow } = require("../lib/sheets");
const { translateToEnglish } = require("../lib/translate");
const { sendAlert } = require("../lib/alert");

const LOW_RATING_MAX = 3;      // alert when rating is 3 or below
const MIN_FILL_MS = 1500;      // page-load to submit faster than this is a bot (kept low so quick real guests are never dropped)
const MAX_BODY_BYTES = 20000;
const RATE_LIMIT = 8;          // submissions per IP per window (best effort, per warm instance)
const RATE_WINDOW_MS = 10 * 60 * 1000;

const hits = new Map();

function rateLimited(ip) {
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((ts) => now - ts < RATE_WINDOW_MS);
  recent.push(now);
  hits.set(ip, recent);
  if (hits.size > 500) for (const [key, list] of hits) if (!list.some((ts) => now - ts < RATE_WINDOW_MS)) hits.delete(key);
  return recent.length > RATE_LIMIT;
}

const reply = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  body: JSON.stringify(body)
});

function localTime(date) {
  // "2026-10-16 14:03:22" in the hosts' time zone
  return date.toLocaleString("sv-SE", { timeZone: "Europe/Bratislava" });
}

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return reply(405, { ok: false });
  if ((event.body || "").length > MAX_BODY_BYTES) return reply(413, { ok: false });

  let body;
  try { body = JSON.parse(event.body || "{}"); } catch { return reply(400, { ok: false }); }

  // Spam protection: honeypot filled or form completed impossibly fast.
  // Answer "ok" so bots learn nothing, and store nothing.
  if ((typeof body.website === "string" && body.website.trim() !== "") || !(body.t >= MIN_FILL_MS)) {
    return reply(200, { ok: true });
  }

  const headers = event.headers || {};
  const ip = headers["x-nf-client-connection-ip"] || (headers["x-forwarded-for"] || "").split(",")[0].trim() || "unknown";
  if (rateLimited(ip)) return reply(429, { ok: false });

  const checked = validate(body, config);
  if (checked.error) return reply(400, { ok: false, error: checked.error });
  const submission = checked.value;
  const { property, rating, comments } = submission;

  const when = localTime(new Date());
  const isLow = rating <= LOW_RATING_MAX;

  // Translate comments to English for low ratings (the only ones that trigger an alert).
  let translations = {};
  if (isLow && Object.keys(comments).length) {
    try {
      const keys = Object.keys(comments);
      const result = await translateToEnglish(keys.map((k) => comments[k]));
      if (result) {
        keys.forEach((k, i) => { if (result[i] && result[i].from !== "en") translations[k] = result[i]; });
      }
    } catch (err) {
      console.error("translation failed:", err.message);
    }
  }

  // Alert email (low ratings only)
  let alertStatus = "-";
  if (isLow) {
    try {
      alertStatus = await sendAlert({ submission, when, translations });
    } catch (err) {
      alertStatus = "FAILED";
      console.error("alert failed:", err.message);
    }
  }

  // Store in the Google Sheet
  const translationCell = Object.keys(translations)
    .map((k) => `${k === "general" ? "General" : k}: ${translations[k].text}`)
    .join("\n");

  const row = [
    when,
    property.label,
    submission.lang,
    rating,
    submission.tags.join(", "),
    comments.general || "",
    ...config.categories.map((c) => comments[c] || ""),
    translationCell,
    alertStatus
  ];

  let stored = true;
  try {
    await appendRow(row);
  } catch (err) {
    stored = false;
    console.error("sheet append failed:", err.message);
  }

  // If neither the sheet nor an alert email captured it, tell the guest so they can retry.
  if (!stored && alertStatus.indexOf("sent") !== 0) return reply(500, { ok: false });

  // Strict gating: only a 5-star response for a property with googleReview enabled gets the link.
  const googleUrl = process.env[`GOOGLE_REVIEW_URL_${submission.propertyId.toUpperCase()}`];
  const google = property.googleReview && rating === 5 && googleUrl ? googleUrl : null;

  return reply(200, { ok: true, google });
};
