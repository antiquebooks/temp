(function () {
  "use strict";

  var I18N = window.I18N;
  var params = new URLSearchParams(location.search);
  var $ = function (id) { return document.getElementById(id); };

  var state = {
    cfg: null,
    pid: null,
    prop: null,
    lang: "en",
    rating: 0,
    tags: {},        // category -> array of tag ids
    comments: {},    // category -> text
    startedAt: Date.now(),
    sending: false,
    errorKey: null
  };

  /* ---------- language ---------- */

  function detectLang() {
    var forced = (params.get("lang") || "").toLowerCase();
    if (I18N.languages.indexOf(forced) !== -1) return forced;
    var prefs = navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language || "en"];
    for (var i = 0; i < prefs.length; i++) {
      var code = String(prefs[i]).toLowerCase().split("-")[0];
      if (I18N.languages.indexOf(code) !== -1) return code;
    }
    return "en";
  }

  function t(path) {
    var dot = path.indexOf(".");
    var group = path.slice(0, dot);
    var key = path.slice(dot + 1);
    var own = I18N[state.lang][group];
    if (own && own[key] !== undefined) return own[key];
    var en = I18N.en[group];
    return en && en[key] !== undefined ? en[key] : key;
  }

  function applyLang() {
    document.documentElement.lang = state.lang;
    if (state.prop) document.title = t("ui.title") + " - " + state.prop.name;

    document.querySelectorAll("[data-i18n]").forEach(function (node) {
      node.textContent = t(node.getAttribute("data-i18n"));
    });
    document.querySelectorAll("[data-i18n-placeholder]").forEach(function (node) {
      node.setAttribute("placeholder", t(node.getAttribute("data-i18n-placeholder")));
    });
    document.querySelectorAll("[data-i18n-aria]").forEach(function (node) {
      node.setAttribute("aria-label", t(node.getAttribute("data-i18n-aria")));
    });

    document.querySelectorAll(".lang").forEach(function (b) {
      b.setAttribute("aria-pressed", String(b.dataset.lang === state.lang));
    });

    // Elements whose text depends on state
    document.querySelectorAll(".star").forEach(function (s) {
      var n = s.dataset.value;
      s.setAttribute("aria-label", n + " / 5, " + t("ui.rating" + n));
    });
    $("rating-word").textContent = state.rating ? t("ui.rating" + state.rating) : "";
    if (state.sending) $("send").textContent = t("ui.sending");
    $("thanks-body").textContent = state.rating && state.rating <= 3 ? t("ui.thanksLow") : t("ui.thanksBody");
    if (state.errorKey) $("error").textContent = t(state.errorKey);
  }

  function buildLangButtons() {
    var nav = $("langs");
    I18N.languages.forEach(function (code) {
      var b = document.createElement("button");
      b.type = "button";
      b.className = "lang";
      b.dataset.lang = code;
      b.textContent = code.toUpperCase();
      b.setAttribute("lang", code);
      b.setAttribute("title", I18N.languageNames[code]);
      b.addEventListener("click", function () { state.lang = code; applyLang(); });
      nav.appendChild(b);
    });
  }

  /* ---------- stars ---------- */

  var stars = [];

  function setRating(n, moveFocus) {
    var first = state.rating === 0;
    state.rating = n;

    stars.forEach(function (s, i) {
      s.classList.toggle("on", i < n);
      s.setAttribute("aria-checked", String(i === n - 1));
      s.tabIndex = i === n - 1 ? 0 : -1;
    });
    if (moveFocus) stars[n - 1].focus();

    var low = n <= 3;
    $("topics").classList.toggle("topics--prominent", low);
    $("topics").classList.toggle("topics--light", !low);
    $("prompt").setAttribute("data-i18n", low ? "ui.promptLow" : "ui.promptHigh");
    $("prompt-hint").setAttribute("data-i18n", low ? "ui.hintLow" : "ui.hintHigh");

    if (first) $("after").hidden = false;
    applyLang();
  }

  function initStars() {
    stars = Array.prototype.slice.call(document.querySelectorAll(".star"));
    stars.forEach(function (s, i) {
      s.tabIndex = i === 0 ? 0 : -1;
      s.addEventListener("click", function () { setRating(i + 1, false); });
      s.addEventListener("keydown", function (e) {
        var n = state.rating || 0;
        var next = null;
        if (e.key === "ArrowRight" || e.key === "ArrowUp") next = Math.min(5, (n || 0) + 1);
        else if (e.key === "ArrowLeft" || e.key === "ArrowDown") next = Math.max(1, (n || 2) - 1);
        else if (e.key === "Home") next = 1;
        else if (e.key === "End") next = 5;
        if (next) { e.preventDefault(); setRating(next, true); }
      });
    });
  }

  /* ---------- topics ---------- */

  function el(tag, attrs) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) { node.setAttribute(k, attrs[k]); });
    for (var i = 2; i < arguments.length; i++) node.appendChild(arguments[i]);
    return node;
  }

  function chevron() {
    var ns = "http://www.w3.org/2000/svg";
    var svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("class", "chev");
    svg.setAttribute("aria-hidden", "true");
    var path = document.createElementNS(ns, "path");
    path.setAttribute("d", "M5 9l7 7 7-7");
    svg.appendChild(path);
    return svg;
  }

  function refreshBadge(cat, topicEl) {
    var has = (state.tags[cat] && state.tags[cat].length) || (state.comments[cat] && state.comments[cat].trim());
    topicEl.querySelector(".topic-badge").hidden = !has;
  }

  function buildTopics() {
    var list = $("topic-list");
    state.cfg.categories.forEach(function (cat) {
      var tags = state.prop.tags[cat] || [];
      state.tags[cat] = [];
      state.comments[cat] = "";

      var headId = "head-" + cat;
      var panelId = "panel-" + cat;

      var head = el("button", { type: "button", class: "topic-head", id: headId, "aria-expanded": "false", "aria-controls": panelId },
        el("span", { class: "topic-text" },
          el("span", { class: "topic-name", "data-i18n": "cat." + cat }),
          el("span", { class: "topic-hint", "data-i18n": "cathint." + cat })),
        el("span", { class: "topic-badge", "data-i18n": "ui.added", hidden: "" }),
        chevron());

      var tagWrap = el("div", { class: "tags" });
      tags.forEach(function (tag) {
        tagWrap.appendChild(el("button", { type: "button", class: "tag", "aria-pressed": "false", "data-tag": tag, "data-i18n": "tag." + tag }));
      });

      var comment = el("textarea", { rows: "3", maxlength: "1000", "data-i18n-placeholder": "ui.commentPlaceholder", "data-i18n-aria": "cat." + cat });

      var panel = el("div", { class: "topic-panel", id: panelId, role: "group", "aria-labelledby": headId, hidden: "" },
        el("p", { class: "tags-label", "data-i18n": "ui.tagsLabel" }),
        tagWrap, comment);

      var topic = el("div", { class: "topic", "data-cat": cat }, head, panel);

      head.addEventListener("click", function () {
        var open = head.getAttribute("aria-expanded") === "true";
        head.setAttribute("aria-expanded", String(!open));
        panel.hidden = open;
      });

      tagWrap.addEventListener("click", function (e) {
        var btn = e.target.closest(".tag");
        if (!btn) return;
        var on = btn.getAttribute("aria-pressed") !== "true";
        btn.setAttribute("aria-pressed", String(on));
        var id = btn.dataset.tag;
        var arr = state.tags[cat];
        if (on && arr.indexOf(id) === -1) arr.push(id);
        if (!on) state.tags[cat] = arr.filter(function (x) { return x !== id; });
        refreshBadge(cat, topic);
      });

      comment.addEventListener("input", function () {
        state.comments[cat] = comment.value;
        refreshBadge(cat, topic);
      });

      list.appendChild(topic);
    });
  }

  /* ---------- submit ---------- */

  function showError(key) {
    state.errorKey = key;
    $("error").hidden = !key;
    if (key) $("error").textContent = t(key);
  }

  function collect() {
    var tags = [];
    var comments = { general: $("general").value };
    state.cfg.categories.forEach(function (cat) {
      state.tags[cat].forEach(function (tag) { tags.push(cat + ":" + tag); });
      comments[cat] = state.comments[cat];
    });
    return {
      p: state.pid,
      rating: state.rating,
      lang: state.lang,
      tags: tags,
      comments: comments,
      website: $("website").value,                 // honeypot
      t: Date.now() - state.startedAt              // time on page, ms
    };
  }

  function showThanks(googleUrl) {
    $("form").hidden = true;
    $("thanks").hidden = false;
    $("thanks-tip").hidden = state.rating > 3;
    $("signoff").textContent = state.cfg.hosts;

    if (typeof googleUrl === "string" && /^https:\/\//.test(googleUrl)) {
      $("google-link").href = googleUrl;
      $("google").hidden = false;
    }
    applyLang();
    window.scrollTo(0, 0);
    $("thanks-title").focus();
  }

  async function submit(e) {
    e.preventDefault();
    if (!state.rating || state.sending) return;
    showError(null);
    state.sending = true;
    $("send").disabled = true;
    $("send").textContent = t("ui.sending");

    try {
      var res = await fetch("/api/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(collect())
      });
      if (res.ok) {
        var data = await res.json();
        state.sending = false;
        showThanks(data && data.google);
        return;
      }
      showError(res.status === 429 ? "ui.errorRate" : "ui.errorGeneric");
    } catch (err) {
      showError("ui.errorGeneric");
    }
    state.sending = false;
    $("send").disabled = false;
    $("send").textContent = t("ui.send");
  }

  /* ---------- start ---------- */

  function showInvalid() {
    $("form").hidden = true;
    $("invalid").hidden = false;
    applyLang();
  }

  async function init() {
    state.lang = detectLang();
    buildLangButtons();
    applyLang();

    var cfg;
    try {
      var res = await fetch("/config.json", { cache: "no-cache" });
      cfg = await res.json();
    } catch (err) {
      return showInvalid();
    }

    var pid = params.get("p");
    if (!pid || !Object.prototype.hasOwnProperty.call(cfg.properties, pid)) return showInvalid();

    state.cfg = cfg;
    state.pid = pid;
    state.prop = cfg.properties[pid];

    document.documentElement.setAttribute("data-p", pid);
    $("prop-name").textContent = state.prop.name;
    $("prop-place").textContent = state.prop.place;
    $("who").hidden = false;

    initStars();
    buildTopics();
    $("form").hidden = false;
    $("form").addEventListener("submit", submit);
    applyLang();
  }

  init();
})();
