/*
 * Translations for the guest feedback form.
 * Works in the browser (window.I18N) and in Node (require) so the alert
 * email can reuse the English labels. Edit wording here only.
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.I18N = factory();
})(typeof self !== "undefined" ? self : this, function () {
  return {
    languages: ["en", "sk", "es", "fr", "de"],
    languageNames: { en: "English", sk: "Slovenčina", es: "Español", fr: "Français", de: "Deutsch" },

    en: {
      ui: {
        title: "Feedback",
        howWas: "How was your stay?",
        rating1: "Poor", rating2: "Fair", rating3: "Okay", rating4: "Good", rating5: "Loved it",
        anon: "Anonymous. We don't ask for your name or contact details.",
        promptLow: "What should we fix?",
        hintLow: "Tap a topic and tell us what went wrong. Short is fine.",
        promptHigh: "Anything we could still improve?",
        hintHigh: "Optional. Tap a topic if something comes to mind.",
        tagsLabel: "Select what applies",
        commentPlaceholder: "Add details (optional)",
        added: "Added",
        generalLabel: "Anything else you'd like to tell us?",
        send: "Send feedback",
        sending: "Sending…",
        thanks: "Thank you",
        thanksBody: "We read every response and use it to improve the place.",
        thanksLow: "Thank you for telling us what went wrong. We'll look into it.",
        thanksLowTip: "If something needs fixing during your stay, message us through your booking.",
        googleTitle: "Glad you enjoyed your stay!",
        googleBody: "Would you share it on Google? It helps future guests find us.",
        googleBtn: "Write a Google review",
        errorGeneric: "Your feedback wasn't sent. Check your connection and try again.",
        errorRate: "Too many responses from this network. Try again in a few minutes.",
        invalidTitle: "This link is incomplete",
        invalidBody: "Scan the QR code in the property again to open the feedback form.",
        langLabel: "Language",
        noscript: "This form needs JavaScript to work."
      },
      cat: {
        cleanliness: "Cleanliness",
        comfort: "Comfort & sleep",
        equipment: "Equipment & amenities",
        condition: "Condition & maintenance",
        checkin: "Check-in & communication",
        location: "Location & surroundings"
      },
      cathint: {
        cleanliness: "Arrival state, bathroom, kitchen, linens",
        comfort: "Beds, noise, temperature, space",
        equipment: "Kitchen items, Wi-Fi, appliances, supplies",
        condition: "Anything broken, worn or not working",
        checkin: "Instructions, key access, responsiveness",
        location: "Neighborhood, parking, access"
      },
      tag: {
        bathroom: "Bathroom", kitchen: "Kitchen", bedding: "Bedding", floors: "Floors", smell: "Smell",
        bed: "Bed / mattress", sofaBed: "Sofa bed", noise: "Noise", tooHot: "Too hot", tooCold: "Too cold", pillows: "Pillows",
        wifi: "Wi-Fi", tv: "TV", cookware: "Cookware", dishwasher: "Dishwasher", washer: "Washing machine",
        coffeeMachine: "Coffee machine", turntable: "Turntable / records", workspace: "Workspace",
        crib: "Baby crib", games: "Billiards / games", toiletries: "Toiletries",
        hotWater: "Hot water", heatingAc: "Heating / AC", lighting: "Lighting", leak: "Leak",
        elevator: "Elevator", broken: "Broken item",
        instructions: "Instructions unclear", access: "Key / access", luggage: "Luggage storage",
        slowReply: "Slow reply", localTips: "Local tips",
        parking: "Parking", streetNoise: "Street noise", transport: "Public transport", stairs: "Stairs",
        garden: "Garden", bbq: "BBQ", outdoorGames: "Ping pong / badminton"
      }
    },

    sk: {
      ui: {
        title: "Spätná väzba",
        howWas: "Ako hodnotíte svoj pobyt?",
        rating1: "Zlé", rating2: "Slabšie", rating3: "Také-onaké", rating4: "Dobré", rating5: "Skvelé",
        anon: "Anonymne. Nepýtame si meno ani kontakt.",
        promptLow: "Čo máme opraviť?",
        hintLow: "Vyberte tému a napíšte, čo nebolo v poriadku. Stačí stručne.",
        promptHigh: "Dalo by sa niečo ešte zlepšiť?",
        hintHigh: "Nepovinné. Ak vám niečo napadne, vyberte tému.",
        tagsLabel: "Vyberte, čo sa týka",
        commentPlaceholder: "Doplňte podrobnosti (nepovinné)",
        added: "Pridané",
        generalLabel: "Chcete nám ešte niečo odkázať?",
        send: "Odoslať spätnú väzbu",
        sending: "Odosielam…",
        thanks: "Ďakujeme",
        thanksBody: "Čítame každú odpoveď a používame ju na zlepšenie ubytovania.",
        thanksLow: "Ďakujeme, že ste nám napísali, čo nevyšlo. Pozrieme sa na to.",
        thanksLowTip: "Ak treba niečo vyriešiť počas pobytu, napíšte nám cez vašu rezerváciu.",
        googleTitle: "Teší nás, že sa vám u nás páčilo!",
        googleBody: "Podelili by ste sa o to aj na Googli? Pomôže to ďalším hosťom nás nájsť.",
        googleBtn: "Napísať recenziu na Googli",
        errorGeneric: "Spätnú väzbu sa nepodarilo odoslať. Skontrolujte pripojenie a skúste to znova.",
        errorRate: "Z tejto siete prišlo príliš veľa odpovedí. Skúste to o niekoľko minút.",
        invalidTitle: "Odkaz je neúplný",
        invalidBody: "Naskenujte QR kód v ubytovaní znova a formulár sa otvorí.",
        langLabel: "Jazyk",
        noscript: "Tento formulár vyžaduje JavaScript."
      },
      cat: {
        cleanliness: "Čistota",
        comfort: "Komfort a spánok",
        equipment: "Vybavenie",
        condition: "Stav a údržba",
        checkin: "Príchod a komunikácia",
        location: "Poloha a okolie"
      },
      cathint: {
        cleanliness: "Stav pri príchode, kúpeľňa, kuchyňa, bielizeň",
        comfort: "Postele, hluk, teplota, priestor",
        equipment: "Kuchynské vybavenie, Wi-Fi, spotrebiče, zásoby",
        condition: "Čokoľvek pokazené, opotrebované alebo nefunkčné",
        checkin: "Pokyny, kľúč, rýchlosť odpovedí",
        location: "Okolie, parkovanie, dostupnosť"
      },
      tag: {
        bathroom: "Kúpeľňa", kitchen: "Kuchyňa", bedding: "Posteľná bielizeň", floors: "Podlahy", smell: "Zápach",
        bed: "Posteľ / matrac", sofaBed: "Rozkladacia pohovka", noise: "Hluk", tooHot: "Príliš teplo", tooCold: "Príliš zima", pillows: "Vankúše",
        wifi: "Wi-Fi", tv: "TV", cookware: "Riad a náčinie", dishwasher: "Umývačka riadu", washer: "Práčka",
        coffeeMachine: "Kávovar", turntable: "Gramofón / platne", workspace: "Pracovný kút",
        crib: "Detská postieľka", games: "Biliard / hry", toiletries: "Toaletné potreby",
        hotWater: "Teplá voda", heatingAc: "Kúrenie / klimatizácia", lighting: "Osvetlenie", leak: "Unikanie vody",
        elevator: "Výťah", broken: "Pokazená vec",
        instructions: "Nejasné pokyny", access: "Kľúč / prístup", luggage: "Úschova batožiny",
        slowReply: "Pomalá odpoveď", localTips: "Tipy na okolie",
        parking: "Parkovanie", streetNoise: "Hluk z ulice", transport: "MHD", stairs: "Schody",
        garden: "Záhrada", bbq: "Gril", outdoorGames: "Stolný tenis / bedminton"
      }
    },

    es: {
      ui: {
        title: "Opinión",
        howWas: "¿Cómo fue tu estancia?",
        rating1: "Mala", rating2: "Regular", rating3: "Aceptable", rating4: "Buena", rating5: "Me encantó",
        anon: "Anónimo. No pedimos tu nombre ni datos de contacto.",
        promptLow: "¿Qué deberíamos arreglar?",
        hintLow: "Toca un tema y cuéntanos qué falló. Basta con algo breve.",
        promptHigh: "¿Algo que aún podamos mejorar?",
        hintHigh: "Opcional. Toca un tema si se te ocurre algo.",
        tagsLabel: "Marca lo que corresponda",
        commentPlaceholder: "Añade detalles (opcional)",
        added: "Añadido",
        generalLabel: "¿Algo más que quieras contarnos?",
        send: "Enviar opinión",
        sending: "Enviando…",
        thanks: "Gracias",
        thanksBody: "Leemos todas las respuestas y las usamos para mejorar el alojamiento.",
        thanksLow: "Gracias por contarnos qué falló. Lo revisaremos con atención.",
        thanksLowTip: "Si algo necesita arreglo durante tu estancia, escríbenos a través de tu reserva.",
        googleTitle: "¡Nos alegra que hayas disfrutado!",
        googleBody: "¿Te gustaría compartirlo en Google? Ayuda a otros viajeros a encontrarnos.",
        googleBtn: "Escribir una reseña en Google",
        errorGeneric: "No se pudo enviar tu opinión. Revisa la conexión e inténtalo de nuevo.",
        errorRate: "Se han enviado demasiadas respuestas desde esta red. Inténtalo en unos minutos.",
        invalidTitle: "El enlace está incompleto",
        invalidBody: "Vuelve a escanear el código QR del alojamiento para abrir el formulario.",
        langLabel: "Idioma",
        noscript: "Este formulario necesita JavaScript."
      },
      cat: {
        cleanliness: "Limpieza",
        comfort: "Comodidad y descanso",
        equipment: "Equipamiento y servicios",
        condition: "Estado y mantenimiento",
        checkin: "Llegada y comunicación",
        location: "Ubicación y entorno"
      },
      cathint: {
        cleanliness: "Estado a la llegada, baño, cocina, ropa de cama",
        comfort: "Camas, ruido, temperatura, espacio",
        equipment: "Cocina, Wi-Fi, electrodomésticos, suministros",
        condition: "Algo roto, desgastado o que no funciona",
        checkin: "Instrucciones, acceso con llave, rapidez de respuesta",
        location: "Barrio, aparcamiento, accesos"
      },
      tag: {
        bathroom: "Baño", kitchen: "Cocina", bedding: "Ropa de cama", floors: "Suelos", smell: "Olor",
        bed: "Cama / colchón", sofaBed: "Sofá cama", noise: "Ruido", tooHot: "Demasiado calor", tooCold: "Demasiado frío", pillows: "Almohadas",
        wifi: "Wi-Fi", tv: "TV", cookware: "Utensilios de cocina", dishwasher: "Lavavajillas", washer: "Lavadora",
        coffeeMachine: "Cafetera", turntable: "Tocadiscos / discos", workspace: "Zona de trabajo",
        crib: "Cuna", games: "Billar / juegos", toiletries: "Artículos de aseo",
        hotWater: "Agua caliente", heatingAc: "Calefacción / A/A", lighting: "Iluminación", leak: "Fuga de agua",
        elevator: "Ascensor", broken: "Objeto roto",
        instructions: "Instrucciones poco claras", access: "Llave / acceso", luggage: "Consigna de equipaje",
        slowReply: "Respuesta lenta", localTips: "Consejos locales",
        parking: "Aparcamiento", streetNoise: "Ruido de la calle", transport: "Transporte público", stairs: "Escaleras",
        garden: "Jardín", bbq: "Barbacoa", outdoorGames: "Ping-pong / bádminton"
      }
    },

    fr: {
      ui: {
        title: "Votre avis",
        howWas: "Comment s'est passé votre séjour ?",
        rating1: "Mauvais", rating2: "Moyen", rating3: "Correct", rating4: "Bien", rating5: "Adoré",
        anon: "Anonyme. Nous ne demandons ni votre nom ni vos coordonnées.",
        promptLow: "Que devons-nous corriger ?",
        hintLow: "Touchez un thème et dites-nous ce qui n'allait pas. Quelques mots suffisent.",
        promptHigh: "Quelque chose à améliorer encore ?",
        hintHigh: "Facultatif. Touchez un thème si quelque chose vous vient à l'esprit.",
        tagsLabel: "Sélectionnez ce qui s'applique",
        commentPlaceholder: "Ajoutez des précisions (facultatif)",
        added: "Ajouté",
        generalLabel: "Autre chose à nous dire ?",
        send: "Envoyer mon avis",
        sending: "Envoi…",
        thanks: "Merci",
        thanksBody: "Nous lisons chaque réponse et nous nous en servons pour améliorer le logement.",
        thanksLow: "Merci de nous avoir dit ce qui n'allait pas. Nous allons y regarder de près.",
        thanksLowTip: "Si quelque chose doit être réglé pendant votre séjour, écrivez-nous via votre réservation.",
        googleTitle: "Ravis que votre séjour vous ait plu !",
        googleBody: "Voulez-vous le partager sur Google ? Cela aide les prochains voyageurs à nous trouver.",
        googleBtn: "Écrire un avis sur Google",
        errorGeneric: "Votre avis n'a pas pu être envoyé. Vérifiez votre connexion et réessayez.",
        errorRate: "Trop de réponses envoyées depuis ce réseau. Réessayez dans quelques minutes.",
        invalidTitle: "Lien incomplet",
        invalidBody: "Scannez à nouveau le QR code du logement pour ouvrir le formulaire.",
        langLabel: "Langue",
        noscript: "Ce formulaire nécessite JavaScript."
      },
      cat: {
        cleanliness: "Propreté",
        comfort: "Confort et sommeil",
        equipment: "Équipements",
        condition: "État et entretien",
        checkin: "Arrivée et communication",
        location: "Emplacement et environs"
      },
      cathint: {
        cleanliness: "État à l'arrivée, salle de bain, cuisine, linge",
        comfort: "Lits, bruit, température, espace",
        equipment: "Cuisine, Wi-Fi, appareils, fournitures",
        condition: "Tout ce qui est cassé, usé ou ne fonctionne pas",
        checkin: "Instructions, remise des clés, réactivité",
        location: "Quartier, stationnement, accès"
      },
      tag: {
        bathroom: "Salle de bain", kitchen: "Cuisine", bedding: "Literie", floors: "Sols", smell: "Odeur",
        bed: "Lit / matelas", sofaBed: "Canapé-lit", noise: "Bruit", tooHot: "Trop chaud", tooCold: "Trop froid", pillows: "Oreillers",
        wifi: "Wi-Fi", tv: "TV", cookware: "Ustensiles de cuisine", dishwasher: "Lave-vaisselle", washer: "Lave-linge",
        coffeeMachine: "Machine à café", turntable: "Platine / disques", workspace: "Espace de travail",
        crib: "Lit bébé", games: "Billard / jeux", toiletries: "Produits de toilette",
        hotWater: "Eau chaude", heatingAc: "Chauffage / clim", lighting: "Éclairage", leak: "Fuite",
        elevator: "Ascenseur", broken: "Objet cassé",
        instructions: "Instructions peu claires", access: "Clé / accès", luggage: "Consigne à bagages",
        slowReply: "Réponse lente", localTips: "Conseils locaux",
        parking: "Parking", streetNoise: "Bruit de la rue", transport: "Transports en commun", stairs: "Escaliers",
        garden: "Jardin", bbq: "Barbecue", outdoorGames: "Ping-pong / badminton"
      }
    },

    de: {
      ui: {
        title: "Feedback",
        howWas: "Wie war Ihr Aufenthalt?",
        rating1: "Schlecht", rating2: "Mäßig", rating3: "In Ordnung", rating4: "Gut", rating5: "Begeistert",
        anon: "Anonym. Wir fragen weder nach Namen noch nach Kontaktdaten.",
        promptLow: "Was sollten wir verbessern?",
        hintLow: "Tippen Sie auf ein Thema und schreiben Sie, was nicht gepasst hat. Kurz genügt.",
        promptHigh: "Können wir noch etwas verbessern?",
        hintHigh: "Optional. Tippen Sie auf ein Thema, wenn Ihnen etwas einfällt.",
        tagsLabel: "Zutreffendes auswählen",
        commentPlaceholder: "Details ergänzen (optional)",
        added: "Hinzugefügt",
        generalLabel: "Möchten Sie uns sonst noch etwas mitteilen?",
        send: "Feedback senden",
        sending: "Wird gesendet…",
        thanks: "Danke",
        thanksBody: "Wir lesen jede Antwort und nutzen sie, um die Unterkunft zu verbessern.",
        thanksLow: "Danke, dass Sie uns gesagt haben, was nicht gepasst hat. Wir schauen es uns genau an.",
        thanksLowTip: "Wenn während Ihres Aufenthalts etwas behoben werden muss, schreiben Sie uns über Ihre Buchung.",
        googleTitle: "Schön, dass es Ihnen gefallen hat!",
        googleBody: "Möchten Sie das auch bei Google teilen? Das hilft anderen Gästen, uns zu finden.",
        googleBtn: "Google-Bewertung schreiben",
        errorGeneric: "Ihr Feedback wurde nicht gesendet. Prüfen Sie die Verbindung und versuchen Sie es erneut.",
        errorRate: "Von diesem Netzwerk wurden zu viele Antworten gesendet. Versuchen Sie es in einigen Minuten erneut.",
        invalidTitle: "Link unvollständig",
        invalidBody: "Scannen Sie den QR-Code in der Unterkunft erneut, um das Formular zu öffnen.",
        langLabel: "Sprache",
        noscript: "Dieses Formular benötigt JavaScript."
      },
      cat: {
        cleanliness: "Sauberkeit",
        comfort: "Komfort & Schlaf",
        equipment: "Ausstattung",
        condition: "Zustand & Wartung",
        checkin: "Anreise & Kommunikation",
        location: "Lage & Umgebung"
      },
      cathint: {
        cleanliness: "Zustand bei Ankunft, Bad, Küche, Wäsche",
        comfort: "Betten, Lärm, Temperatur, Platz",
        equipment: "Küchenausstattung, WLAN, Geräte, Verbrauchsmaterial",
        condition: "Alles, was kaputt, abgenutzt oder defekt ist",
        checkin: "Anleitung, Schlüsselübergabe, Erreichbarkeit",
        location: "Umgebung, Parken, Zugang"
      },
      tag: {
        bathroom: "Badezimmer", kitchen: "Küche", bedding: "Bettwäsche", floors: "Böden", smell: "Geruch",
        bed: "Bett / Matratze", sofaBed: "Schlafsofa", noise: "Lärm", tooHot: "Zu warm", tooCold: "Zu kalt", pillows: "Kissen",
        wifi: "WLAN", tv: "TV", cookware: "Kochgeschirr", dishwasher: "Geschirrspüler", washer: "Waschmaschine",
        coffeeMachine: "Kaffeemaschine", turntable: "Plattenspieler / Platten", workspace: "Arbeitsplatz",
        crib: "Babybett", games: "Billard / Spiele", toiletries: "Pflegeprodukte",
        hotWater: "Warmwasser", heatingAc: "Heizung / Klima", lighting: "Beleuchtung", leak: "Undichte Stelle",
        elevator: "Aufzug", broken: "Defekter Gegenstand",
        instructions: "Unklare Anleitung", access: "Schlüssel / Zugang", luggage: "Gepäckaufbewahrung",
        slowReply: "Langsame Antwort", localTips: "Tipps zur Umgebung",
        parking: "Parkplatz", streetNoise: "Straßenlärm", transport: "Öffentlicher Verkehr", stairs: "Treppen",
        garden: "Garten", bbq: "Grill", outdoorGames: "Tischtennis / Badminton"
      }
    }
  };
});
